package com.teamshort.viberbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViberbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViberbotApplication.class, args);
	}
}
